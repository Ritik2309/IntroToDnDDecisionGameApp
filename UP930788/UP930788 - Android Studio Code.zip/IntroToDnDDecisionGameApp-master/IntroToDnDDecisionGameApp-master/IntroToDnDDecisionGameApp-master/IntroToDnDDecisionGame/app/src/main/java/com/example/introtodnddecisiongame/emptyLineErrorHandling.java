package com.example.introtodnddecisiongame;


public class emptyLineErrorHandling extends Exception {
    public emptyLineErrorHandling(String input){
       super(input);
    }
}
