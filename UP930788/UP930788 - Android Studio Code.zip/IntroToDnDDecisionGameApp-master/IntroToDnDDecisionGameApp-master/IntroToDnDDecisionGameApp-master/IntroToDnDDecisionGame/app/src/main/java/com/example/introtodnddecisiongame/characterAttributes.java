package com.example.introtodnddecisiongame;

public class characterAttributes {

    static int strength ;
    static int dexterity ;
    static int constitution ;
    static int Intelligence;
    static int wisdom ;
    static int charisma;

    static int strengthMod ;
    static int dexterityMod ;
    static int constitutionMod ;
    static int intelligenceMod ;
    static int wisdomMod ;
    static int charismaMod ;

    public static int getStrengthMod() { return strengthMod; }

    public void setStrengthMod(int strengthMod) { this.strengthMod = strengthMod;}

    public static int getDexterityMod() { return dexterityMod;}

    public void setDexterityMod(int dexterityMod) {this.dexterityMod = dexterityMod;}

    public static int getConstitutionMod() {return constitutionMod; }

    public void setConstitutionMod(int constitutionMod) { this.constitutionMod = constitutionMod;}

    public static int getIntelligenceMod() {return intelligenceMod;}

    public void setIntelligenceMod(int intelligenceMod) { this.intelligenceMod = intelligenceMod;}

    public static int getWisdomMod() {return wisdomMod;}

    public void setWisdomMod(int wisdomMod) {this.wisdomMod = wisdomMod;}

    public static int getCharismaMod() {return charismaMod; }

    public void setCharismaMod(int charismaMod) { this.charismaMod = charismaMod; }




    public static int getStrength() { return strength;}

    public void setStrength(int strength) { this.strength = strength;}

    public static int getDexterity() { return dexterity;}

    public void setDexterity(int dexterity) {this.dexterity = dexterity;}

    public static int getConstitution() {return constitution;}

    public void setConstitution(int constitution) { this.constitution = constitution;}

    public static int getIntelligence() { return Intelligence; }

    public void setIntelligence(int intelligence) { Intelligence = intelligence;}

    public static int getWisdom() { return wisdom;}

    public void setWisdom(int wisdom) { this.wisdom = wisdom;}

    public static int getCharisma() { return charisma;}

    public void setCharisma(int charisma) {this.charisma = charisma;}


}
